import vm from "vm"
import Run from "../models/run.js"
import Node from "../models/node.js"

// ── Registry — add new node type = add 1 import + 1 line here ──────────────
import http_request from "./nodes/httprequest.js"
import condition    from "./nodes/condition.js"
import delay        from "./nodes/delay.js"
import notify       from "./nodes/notify.js"

export const nodeRegistry = {
  http_request,
  condition,
  delay,
  notify,
}

const MAX_RETRIES    = 3
const NODE_TIMEOUT   = 10_000  // 10 seconds per node

function getNextNodeRef(node, currentNodeRef, sortedNodes, result) {

  // ── Condition node — pick branch based on result ─────────────────────────
  if (node.type === "condition") {
    const branchRef = result.conditionResult
      ? currentNodeRef.nextOnTrue
      : currentNodeRef.nextOnFalse

    if (!branchRef) return null  // no branch defined — end workflow

    // Find the branch node ref by order
    return sortedNodes.find(n => n.order === branchRef.order) || null
  }

  // ── Explicit nextNodeId set — jump to that specific node ─────────────────
  if (currentNodeRef.nextNodeId) {
    return sortedNodes.find(n => n.order === currentNodeRef.nextNodeId.order) || null
  }

  // ── Default — go to next node by order ───────────────────────────────────
  const currentOrder = currentNodeRef.order
  const nextInOrder  = sortedNodes
    .filter(n => n.order > currentOrder)
    .sort((a, b) => a.order - b.order)[0]

  return nextInOrder || null  // null = end of workflow
}

// ── Main entry point ────────────────────────────────────────────────────────
export async function executeWorkflow(workflow, run) {
  await Run.findByIdAndUpdate(run._id, { status: "running" })

  const sortedNodes = [...workflow.nodes].sort((a, b) => a.order - b.order)
  let currentOutput = run.triggerPayload || {}

  // Always start at the first node
  let currentNodeRef = sortedNodes[0]

  while (currentNodeRef) {
    const node = await Node.findById(currentNodeRef.nodeId)

    if (!node) {
      await failRun(run._id, `Node ${currentNodeRef.nodeId} not found`)
      return
    }

    // Apply transformQuery if set
    if (node.transformQuery) {
      try {
        currentOutput = vm.runInNewContext(
          node.transformQuery,
          { output: currentOutput },
          { timeout: 1000 }
        )
      } catch (err) {
        await failRun(run._id, `transformQuery failed: ${err.message}`)
        return
      }
    }

    // Execute node with retry
    const startedAt = new Date()
    const { result, error, retryCount } = await executeWithRetry(node, currentOutput)
    const endedAt = new Date()

    // Save log for this node
    await Run.findByIdAndUpdate(run._id, {
      $push: {
        nodeLogs: {
          nodeId:      node._id,
          nodeName:    node.name,
          nodeType:    node.type,
          order:       currentNodeRef.order,
          status:      error ? "failed" : "success",
          input:       currentOutput,
          output:      result ?? null,
          error:       error ? { message: error.message, stack: error.stack } : undefined,
          retryCount,
          startedAt,
          endedAt,
          duration:    endedAt - startedAt,
          branchTaken: node.type === "condition"
            ? (result?.conditionResult ? "true branch" : "false branch")
            : undefined,
        }
      }
    })

    if (error) {
      await failRun(run._id, error.message)
      return
    }

    currentOutput = result

    // ── Decide what node to run next ──────────────────────────────────────
    currentNodeRef = getNextNodeRef(node, currentNodeRef, sortedNodes, result)
  }

  // Loop exited cleanly — all nodes done
  const endedAt = new Date()
  await Run.findByIdAndUpdate(run._id, {
    status:   "success",
    endedAt,
    duration: endedAt - new Date(run.startedAt),
  })
}

// ── Retry wrapper ────────────────────────────────────────────────────────────
async function executeWithRetry(node, input) {
  const handler = nodeRegistry[node.type]
  if (!handler) {
    return { result: null, error: new Error(`Unknown node type: "${node.type}"`), retryCount: 0 }
  }

  let retryCount = 0
  let lastError

  while (retryCount <= MAX_RETRIES) {
    try {
      const result = await Promise.race([
        handler(node.config, input),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Node timed out after ${NODE_TIMEOUT}ms`)), NODE_TIMEOUT)
        )
      ])
      return { result, error: null, retryCount }
    } catch (err) {
      lastError = err
      retryCount++
      if (retryCount <= MAX_RETRIES) {
        // Exponential backoff: 1s, 2s, 4s
        await new Promise(r => setTimeout(r, 1000 * Math.pow(2, retryCount - 1)))
      }
    }
  }

  return { result: null, error: lastError, retryCount }
}

// ── Helper ───────────────────────────────────────────────────────────────────
async function failRun(runId, reason) {
  await Run.findByIdAndUpdate(runId, {
    status:  "failed",
    endedAt: new Date(),
  })
  console.error(`Run ${runId} failed: ${reason}`)
}